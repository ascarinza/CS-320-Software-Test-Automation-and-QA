import java.util.ArrayList;

public class TaskService {

	private ArrayList<Task> taskList;
	
	public TaskService() {
		this.taskList = new ArrayList<>();
	}
	
	//Adds task to contact list if it passes all the constructor requirements
	public boolean addTask (Task task) {
		if (!taskList.isEmpty()) {
				
			for (Task t : taskList) {
				if (t.getTaskId().equals(task.getTaskId())) {
					return false; //This will ensure only unique taskIds are allowed to be added 
				}
			}
		}
		
		//If taskId does not exist it will be allowed to be entered and we pass true back to the Contact constructor
		taskList.add(task);
		return true;
	}
	
	//Removes the given task via taskId if it exists
	public boolean removeTask(String taskId) {
		for (Task t : taskList) {
			if (t.getTaskId().equals(taskId)) {
				taskList.remove(t);
				return true;
			}
		}
		
		//task not found and therefore not removed
		return false;
	}
	
	//Find and returns task given Id
    public Task getTask(String taskId) {
        for (Task t : taskList) {
            if (t.getTaskId().equals(taskId)) {
                return t;
            }
        }
        
        // Task not found
        return null; 
    }
    
    //Used to update an existing task
    public boolean updateTask(Task task, String taskName, String taskDescription) {
        if (taskName != null && !taskName.isEmpty() && taskName.length() <= 10) {
            task.setTaskName(taskName);
        }
        else {
        	return false;
        }
        if (taskDescription != null && !taskDescription.isEmpty() && taskDescription.length() <= 50) {
            task.setTaskDescription(taskDescription);
        }
        else {
        	return false;
        }
        
        return true; //updated correctly
        
    }
        
}