import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	
	private TaskService taskService = new TaskService();
	
	@Test
	void testAddTask() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		assertTrue(taskService.addTask(task));
	}
	
	@Test
	void testAddBadTask() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		Task task2 = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.addTask(task2));
	}
	
	@Test
	void testRemoveTask() {
		Task task = new Task("54321", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertTrue(taskService.removeTask(task.getTaskId()));
	}
	
	@Test
	void testRemoveTaskNotFound() {
		Task task = new Task("54321", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.removeTask("0"));
	}
	
	@Test
	void testUpdateTaskName() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertTrue(taskService.updateTask(task, "Work", "Hw for the week"));
		assertEquals("Work", taskService.getTask(task.getTaskId()).getTaskName());
	}
	
	@Test
	void testUpdateTaskDescription() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertTrue(taskService.updateTask(task, "Homework", "Work for this week"));
		assertEquals("Work for this week", taskService.getTask(task.getTaskId()).getTaskDescription());
		
	}
	
	@Test
	void testFailUpdateTaskNameTooLong() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.updateTask(task, "Homework for this coming week", "Hw for the week"));
		assertNotEquals("Homework for this coming week", taskService.getTask(task.getTaskId()).getTaskName());
	}
	
	@Test
	void testFailUpdateTaskDescriptionToolLong() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.updateTask(task, "Homework", "Hw for the week that must be completed for both Thursday and Sunday afternoon"));
		assertNotEquals("Hw for the week that must be completed for both Thursday and Sunday afternoon", taskService.getTask(task.getTaskId()).getTaskDescription());
		
	}
	
	@Test
	void testFailUpdateTaskNameNull() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.updateTask(task, null, "Hw for the week"));
		assertEquals("Homework", taskService.getTask(task.getTaskId()).getTaskName());
	}
	
	@Test
	void testFailUpdateTaskDescriptionNull() {
		Task task = new Task("12345", "Homework", "Hw for the week");
		taskService.addTask(task);
		assertFalse(taskService.updateTask(task, "Homework", null));
		assertEquals("Hw for the week", taskService.getTask(task.getTaskId()).getTaskDescription());
		
	}
	
	
}
