public class Task {
	
	private String taskId;
	private String taskName;
	private String taskDescription;

		public Task(String taskId, String taskName, String taskDescription) {
		
		//Check for valid tasktId
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
		
        // Check for valid task name
        if (taskName == null || taskName.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }

        // Check for valid description
        if (taskDescription == null || taskDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        
        this.taskId = taskId;
        this.taskName = taskName;
        this.taskDescription = taskDescription;

	}
	
	//Get methods for task 
	public String getTaskId() {
		return taskId;
	}
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	
	//Update methods used to update needed areas of the task
    public void setTaskName(String taskName) {
        if (taskName == null || taskName.length() > 10) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.taskName = taskName;
    }

    public void setTaskDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid task Descriprion");
        }
        this.taskDescription = taskDescription;
    }

}