import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	//test to ensure object is created correctly
	@Test
	void testTask() {
		Task task = new Task("12345", "Homework", "This weeks homework due Tuesday");
		assertTrue(task.getTaskId().equals("12345"));
		assertTrue(task.getTaskName().equals("Homework"));
		assertTrue(task.getTaskDescription().equals("This weeks homework due Tuesday"));
	}
	

	//Tests to ensure variables stored are valid 

	@Test
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task("1234567891011", "Homework", "This weeks hw");
	}); 
	}
	
	@Test
	void testTaskIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task(null, "Homework", "This weeks hw");
	}); 
	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task("12345", "Homework Due this week or next", "This weeks hw");
	}); 
	}
	
	@Test
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task("12345", null, "This weeks hw");
	}); 
	}
	
	@Test
	void testTaskDescriptionLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task("12345", "Homework", "This weeks hw that I must complete by thursday and the rest by sunday afternoon by the latest.");
	}); 
	}
	
	@Test
	void testTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Task("12345", "Homework", null);
	}); 
	}
	

}
