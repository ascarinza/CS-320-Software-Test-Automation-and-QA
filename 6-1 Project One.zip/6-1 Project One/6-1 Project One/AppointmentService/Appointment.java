import java.util.Date;

public class Appointment {
	
	public String appointmentId;
	public Date appointmentDate;
	public String appointmentDescription;
	
	public Appointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		
		//Check for valid appointmentID
        if (appointmentId == null || appointmentId.isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        
		//Check for valid appointment date
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid date");
        }
        
		//Check for valid description
        if (appointmentDescription == null || appointmentDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
        
        // If all inputs are valid, assign input 
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.appointmentDescription = appointmentDescription;
        
	}
	
	//Get methods
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
}
