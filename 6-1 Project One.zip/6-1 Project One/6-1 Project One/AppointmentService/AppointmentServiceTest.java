import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;


import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
	private AppointmentService appointmentService = new AppointmentService();
	
	@Test
	void testAddAppointment() {
		Date date = new Date(2025, 4, 15);
		Appointment appointment = new Appointment("5", date, "Regular call ahead");
		assertTrue(appointmentService.addAppointment(appointment));
	}
	
	@Test
	void testAddingBadAppointment() {
		Date date = new Date(2025, 4, 15);
		Appointment appointment = new Appointment("5", date, "Regular call ahead");
		Appointment appointment2 = new Appointment("5", date, "Regular call ahead");
		appointmentService.addAppointment(appointment);
		assertFalse(appointmentService.addAppointment(appointment2));
	}
	
	@Test
	void testRemoveAppointment() {
		Date date = new Date(2025, 2, 2);
		Appointment appointment = new Appointment("3", date, "Nothing special");
		appointmentService.addAppointment(appointment);
		assertTrue(appointmentService.removeAppointment(appointment.getAppointmentId()));
	}
	
	@Test
	void testRemoveAppointmentNotFound() {
		assertFalse(appointmentService.removeAppointment("0"));
	}

}
