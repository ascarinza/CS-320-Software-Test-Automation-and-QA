import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentTest {

	@Test
	void testAppointment() {
		Date date = new Date(2024, 8, 3);
		Appointment appointment = new Appointment("12345", date, "Weekly check-up");
		assertTrue(appointment.getAppointmentId().equals("12345"));
		assertTrue(appointment.getAppointmentDate().equals(date));
		assertTrue(appointment.getAppointmentDescription().equals("Weekly check-up"));
		
	}
	
	@Test
	void testAppointmentIdTooLong() {
		Date date = new Date(2024, 8, 3);
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment("12345678910", date, "Weekly check-up");
	});
	}
	
	@Test
	void testAppointmentIdNull() {
		Date date = new Date(2024, 8, 3);
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment(null, date, "Weekly check-up");
	});
	}
	
	@Test
	void testAppointmentDateinPast() {
		Date date = new Date(2023, 5, 17);
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment("12345678910", date, "Weekly check-up");
	});
	}
	
	@Test
	void testAppointmentDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment("12345678910", null, "Weekly check-up");
	});
	}
	
	@Test
	void testAppointmentDescriptionLong() {
		Date date = new Date(2024, 8, 3);
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment("12345678910", date, "Weekly check-up for Austin Scarinza, call ahead from April of last year");
	});
	}
	
	@Test
	void testAppointmentDescriptionNull() {
		Date date = new Date(2024, 8, 3);
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Appointment("12345678910", date, null);
	});
	}
	
	
	

}
