import java.util.ArrayList;
import java.util.Date;


public class AppointmentService {

	// Will store out appointments
	private ArrayList<Appointment> appointmentList;
	
	//Create a new list
	public AppointmentService() {
		this.appointmentList = new ArrayList<>();
	}
	
	//Add appointment to appointmentList
	public boolean addAppointment(Appointment newAppointment) {
		if (!appointmentList.isEmpty()) {
			
			// Search for existing contactId
			for (Appointment a : appointmentList) {
				if (a.getAppointmentId().equals(newAppointment.getAppointmentId())) {
					return false;
				}
			}
		}
		
		//If it can be added, add it
		appointmentList.add(newAppointment);
		return true;
	}
	
	// Remove appointment from list
	public boolean removeAppointment(String appointmentId) {
		for (Appointment a : appointmentList) {
			if (a.getAppointmentId().equals(appointmentId)) {
				
				//Found the appointmentId we want to remove then remove it 
				appointmentList.remove(a);
				return true;
			}
		}
		
		//appiontmentId given not found and therefore not removed
		return false;
	}
}
	

