import java.util.ArrayList;

public class ContactService {

	private ArrayList<Contact> contactList;
	
	public ContactService() {
		this.contactList = new ArrayList<>();
	}
	
	//Adds contact to contact list if it passes all the constructor requirements
	public boolean addContact (Contact contact) {
		if (!contactList.isEmpty()) {
				
			for (Contact c : contactList) {
				if (c.getContactId().equals(contact.getContactId())) {
					return false; //This will ensure only unique contactId are allowed to be added 
				}
			}
		}
		
		//If contactId does not exist it will be allowed to be entered and we pass true back to the Contact constructor
		contactList.add(contact);
		System.out.println("Contact Added");
		return true;
	}
	
	//Removes the given contact via contactId if it exists
	public boolean removeContact(String contactId) {
		for (Contact c : contactList) {
			if (c.getContactId().equals(contactId)) {
				contactList.remove(c);
				return true;
			}
		}
		
		//contact not found and therefore not removed
		return false;
	}
	
	//Find contact given Id
    public Contact getContact(String contactId) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                return c;
            }
        }
        
        // Contact ID not found
        return null; 
    }
    
    //Used to update an existing contact
    public boolean updateContact(Contact contact, String firstName, String lastName, String phone, String address) {

        if (firstName != null && !firstName.isEmpty() && firstName.length() <= 10) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && !lastName.isEmpty() && lastName.length() <= 10) {
            contact.setLastName(lastName);
        }
        if (phone != null && phone.length() == 10) {
            contact.setPhone(phone);
        }
        if (address != null && address.length() < 30) {
            contact.setAddress(address);
        }
        return true;
    }
    
}
