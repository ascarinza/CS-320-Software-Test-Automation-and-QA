import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	private ContactService contactService = new ContactService();
	
	@Test
	void testAddContact() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		assertTrue(contactService.addContact(contact));
	}
	
	@Test
	void testAddBadContact() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		Contact contact2 = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertFalse(contactService.addContact(contact2));
	}
	
	@Test
	void testRemoveContact() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertTrue(contactService.removeContact(contact.getContactId()));
	}
	
	@Test
	void testRemoveContactNotFound() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertFalse(contactService.removeContact("0"));
	}
	
	@Test
	void TestUpdateFirstName() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertTrue(contactService.updateContact(contact, "Bob", "Scarinza", "1234567891", "12 Fake Road"));
		assertEquals("Bob", contactService.getContact(contact.getContactId()).getFirstName());
	}
	
	@Test
	void TestUpdateLastName() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertTrue(contactService.updateContact(contact, "Austin", "Clark", "1234567891", "12 Fake Road"));
		assertEquals("Clark", contactService.getContact(contact.getContactId()).getLastName());
	}
	
	@Test
	void TestUpdatePhone() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertTrue(contactService.updateContact(contact, "Austin", "Scarinza", "0987654321", "12 Fake Road"));
		assertEquals("0987654321", contactService.getContact(contact.getContactId()).getPhone());
	}
	
	@Test
	void TestUpdateAddress() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		contactService.addContact(contact);
		assertTrue(contactService.updateContact(contact, "Austin", "Clark", "1234567891", "99 Real Road"));
		assertEquals("99 Real Road", contactService.getContact(contact.getContactId()).getAddress());
	}
	
}
