import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testcontact() {
		Contact contact = new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road");
		assertTrue(contact.getContactId().equals("12345"));
		assertTrue(contact.getFirstName().equals("Austin"));
		assertTrue(contact.getLastName().equals("Scarinza"));
		assertTrue(contact.getPhone().equals("1234567891"));
		assertTrue(contact.getAddress().equals("12 Fake Road"));
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("1234567891011", "Austin", "Scarinza", "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testContactIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact(null, "Austin", "Scarinza", "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "AustinScarinza", "Scarinza", "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", null, "Scarinza", "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "Austin", "ScarinzaAustin", "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "Austin", null, "1234567891", "12 Fake Road");
	}); 
	}
	
	@Test
	void testPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "Austin", "Scarinza", null, "12 Fake Road");
	}); 
	}
	
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "Austin", "Scarinza", "1234567891", "12 Fake Road Manchester New Hampshire United States");
	}); 
	}
	
	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> {new Contact("12345", "Austin", "Scarinza", "1234567891", null);
	}); 
	}
	
	

}
